
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'second-cmp',
    template: ``
})

export class SecondComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}